var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var NewScript = /** @class */ (function (_super) {
    __extends(NewScript, _super);
    function NewScript() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /**
         * 测试属性
         */
        _this.t_attr = 1;
        return _this;
    }
    /**
     * 初始化时调用
     */
    NewScript.prototype.init = function () {
    };
    /**
     * 更新
     */
    NewScript.prototype.update = function () {
        this.transform.ry += this.t_attr;
    };
    /**
     * 销毁时调用
     */
    NewScript.prototype.dispose = function () {
    };
    __decorate([
        feng3d.serialize,
        feng3d.oav()
    ], NewScript.prototype, "t_attr", void 0);
    return NewScript;
}(feng3d.Script));
//# sourceMappingURL=project.js.map